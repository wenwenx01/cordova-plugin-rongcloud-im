module.exports = {
    entry: "./build/index.js",
    output: {
        path: __dirname,
        filename: "page.js"
    },
    module: {}
};